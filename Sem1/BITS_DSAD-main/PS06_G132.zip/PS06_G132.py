import os.path
from os import path


# Function to read the input file - inputps6.txt
def read_pantry_file():
    fileExists = False
    pantry_list = []
    if path.exists('inputPS6.txt'):
        fileExists = True        
        with open('inputPS6.txt', 'rt') as f:
            data = list(line for line in (l.strip() for l in f) if line)
            for each_dishes in data:
                pantry_list.append(each_dishes.strip())
            return fileExists, pantry_list
    else:
        return fileExists, pantry_list


# Function to check the balanced Dish using Greedy Method
def max_balance_dish(ingredients):
    salt = 0
    pepper = 0
    max_dish = 0
    try:
        # Code that may raise an error
        if (len(ingredients) % 2) != 0:
            return "Please enter correct ingredients"
        else:
            # code to run if no error is raised
            for each_ingredients in ingredients:
                if each_ingredients == 'S':
                    salt += 1
                else:
                    pepper += 1
                if salt == pepper:
                    max_dish += 1
                    salt = 0
                    pepper = 0
            return max_dish
    except:
        print("An error occurred")


# Function for creating output file - outputps6.txt
def write_pantry_file(result):
    with open('outputPS6.txt', 'w+') as output:
        for count in result:
            output.write('{}\n'.format(count))


# Main drive Function
if __name__ == '__main__':
    fileExists, pantry_list = read_pantry_file()
    if fileExists == True:
        if len(pantry_list) > 0:
            result = []
            for each in pantry_list:
                result.append(max_balance_dish(each))
            write_pantry_file(result)
        else:
            print("The given input file is empty")
    else:
        print("Unable to find the input file-inputps6.txt in the path")

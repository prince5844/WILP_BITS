#!/usr/bin/env python
# coding: utf-8

import os.path
from os import path

# Function for Reading file inputps06a
def readCitizenFile():
    fileExists=False
    citizenName=[]
    citizenDoseDate=[]
    totalCitizen=''
    if path.exists('inputPS06a.txt'):
        fileExists=True
        with open('inputPS06a.txt','rt') as f:
            data=f.readlines()
            totalCitizen=len(data)
            for i in range(len(data)):
                citizenName.append(data[i].strip().split(',')[0])
                citizenDoseDate.append(int(data[i].strip().split(',')[1].strip()))
            return fileExists, citizenName, citizenDoseDate, totalCitizen
    else:
        return fileExists, citizenName, citizenDoseDate, totalCitizen
    
# Function for Reading file inputps06b
def readNewCitizenFile():
    fileExists=False
    newCitizenName=[]
    newcitizenDoseDate=[]
    nextCitizenCount=[]
    totalNewCitizen=''
    if path.exists('inputPS06b.txt'):
        fileExists=True
        with open('inputPS06b.txt','rt') as f:       
            for i in f:
                if i.startswith('newCitizen:'):
                    out=i[11:].split(',')            
                    name=out[0].strip()
                    id=int(out[1].strip())
                    newCitizenName.append(name)
                    newcitizenDoseDate.append(id)
                if i.startswith('nextCitizen:'):
                    out=int(i[12:].strip())
                    nextCitizenCount.append(out)
            totalNewCitizen=len(newCitizenName)
        return fileExists,newCitizenName, newcitizenDoseDate, totalNewCitizen,nextCitizenCount
    else:
        return fileExists,newCitizenName, newcitizenDoseDate, totalNewCitizen,nextCitizenCount

# Function for creating output file outputps06
def createOutputFile(totalCitizen,originalQueue):
    with open('outputPS06.txt','w+') as f:    
        f.write('-----------------Registered Citizen--------------------\n')
        f.write('No of citizens\n')
        f.write('added:{} Refreshed\n'.format(totalCitizen))
        f.write('queue:\n')
        for i in range(totalCitizen):
            f.write('{},{}\n'.format(originalQueue[i][0],originalQueue[i][1]))
            
# Function to update output file outputps06
def updateOutputFile(totalCitizen,totalNewCitizen,nextCitizenCount,newCitizen,updatedQueue):
    with open('outputPS06.txt','a+') as f:    
        for i in range(totalNewCitizen):
            f.write('New Citizen entered\n')
            f.write('Citizen Details:{},{}\n'.format(newCitizen.Citizen_name()[i],newCitizen.Citizen_Cid()[i]))
        f.write('Refreshed Queue:\n')
        for i in range(totalCitizen+totalNewCitizen):
            f.write('{},{}\n'.format(updatedQueue[i][0],updatedQueue[i][1]))
        if nextCitizenCount:
            f.write('-------------- next citizen : {} -----------\n'.format(nextCitizenCount[0]))
            for i in range(nextCitizenCount[0]):
                f.write('Next citizen for vaccination is:{},{}\n'.format(updatedQueue[i][0],updatedQueue[i][1]))

# Citizen Record Data structure         
class CitizenRecord:    
    def __init__(self,name,date,Cid):        
        self.name=name
        self.date=date
        self.CitId= [int(str(Cid)+str(i)) for i in date]
    def Citizen_name(self):
        return self.name
    def Citizen_date(self):
        return self.date
    def Citizen_Cid(self):
        return self.CitId
    
# VaccinationQueue structure(min heap algorithm)
class VaccinationQueue:   

    def registerCitizen(self, name, date):
        self.name=name
        self.date=date
        self.elements= list(zip(date,name))
        self.h = []
        # Track current index of labels.
        self.index = {}
        if self.elements is not None:
            self._heapify(self.elements)

    def __len__(self):
        return len(self.h)

    def _label(self, element):
        if isinstance(element, tuple) and len(element) == 2:
            return element[1]
        return element

    def _val(self, element):
        if isinstance(element, tuple) and len(element) == 2:
            return element[0]
        return element

    def _parent_index(self, index):
        return (index - 1) // 2

    def _left_child(self, index):
        return (index * 2) + 1

    def _right_child(self, index):
        return (index * 2) + 2    

    def _heapify(self, elements):
        self.h = []
        for e in elements:
            self.enqueueCitizen(e)
            
    def nextCitizen(self):        
        if len(self.h) == 0:
            return None
        elif len(self.h) == 1:
            self.index = {}
            return self.h.pop()
        top_label = self._label(self.h[0])
        bottom_label = self._label(self.h[-1])
        del self.index[top_label]
        self.index[bottom_label] = 0
        element = self.h[0]
        self.h[0] = self.h.pop()
        self._sift_down()
        return element

    def _sift_up(self, i=None):
        if i is None:
            i = len(self.h) - 1
        p = self._parent_index(i)
        while p >= 0 and self._val(self.h[p]) > self._val(self.h[i]):
            self.h[i], self.h[p] = self.h[p], self.h[i]
            # Update label indices.
            self.index[self._label(self.h[i])], self.index[self._label(self.h[p])] = (
                self.index[self._label(self.h[p])],
                self.index[self._label(self.h[i])],
            )
            i = p
            p = self._parent_index(i)
        return i

    def _sift_down(self, i=None):
        if i is None:
            i = 0
        while True:
            l = self._left_child(i)
            r = self._right_child(i)
            smallest = i
            if l < len(self.h) and self._val(self.h[i]) > self._val(self.h[l]):
                smallest = l
            if r < len(self.h) and self._val(self.h[smallest]) > self._val(self.h[r]):
                smallest = r
            if smallest != i:
                self.h[i], self.h[smallest] = self.h[smallest], self.h[i]
                # Update label indices.
                self.index[self._label(self.h[i])], self.index[
                    self._label(self.h[smallest])
                ] = (
                    self.index[self._label(self.h[smallest])],
                    self.index[self._label(self.h[i])],
                )
                smallest = i
            else:
                return i

    def is_empty(self):
        return len(self.h) == 0

    def currentSmallest(self):
        return self.h[0] if len(self.h) > 0 else None

    def enqueueCitizen(self, element):
        label = self._label(element)
        if label in self.index:
            print(f"data with citizenid '{label}' already exists.")
            exit(0)
        self.h.append(element)
        self.index[label] = len(self.h) - 1
        return self._sift_up()

    def _dequeueCitizen(self):
        """Remove element with smallest value in heap, then re-heapify heap.
            Returns:
                Element with smallest value in the heap.
        """
        if len(self.h) == 0:
            return 'No one is there to vaccinate'
        elif len(self.h) == 1:
            self.index = {}
            return self.h.pop()
        top_label = self._label(self.h[0])
        bottom_label = self._label(self.h[-1])
        del self.index[top_label]
        self.index[bottom_label] = 0
        element = self.h[0]
        self.h[0] = self.h.pop()
        self._sift_down()
        return element

# Main drive Function 
def main():
    fileExists,citizenName,citizenDoseDate,totalCitizen=readCitizenFile()
    if fileExists==True:
        citizen=CitizenRecord(citizenName,citizenDoseDate,1)
        vaccinationQueue=VaccinationQueue()
        vaccinationQueue.registerCitizen(citizen.Citizen_name(),citizen.Citizen_Cid())
        originalQueue=[]
        while not vaccinationQueue.is_empty():
            originalQueue.append(vaccinationQueue._dequeueCitizen()) 
        createOutputFile(totalCitizen,originalQueue)
        fileExists,newCitizenName,newcitizenDoseDate,totalNewCitizen,nextCitizenCount=readNewCitizenFile()
        if fileExists==True:
            newCitizen=CitizenRecord(newCitizenName,newcitizenDoseDate,1)
            vaccinationQueue=VaccinationQueue()
            vaccinationQueue.registerCitizen(citizen.Citizen_name()+newCitizen.Citizen_name(),citizen.Citizen_Cid()+newCitizen.Citizen_Cid())
            updatedQueue=[]
            while not vaccinationQueue.is_empty():
                updatedQueue.append(vaccinationQueue._dequeueCitizen())
            updateOutputFile(totalCitizen, totalNewCitizen,nextCitizenCount,newCitizen,updatedQueue)
        else:
            print("Unable to find the input file-inputps06b.txt in the path")
    else:
        print("Unable to find the input file-inputps06a.txt in the path")
        
main()